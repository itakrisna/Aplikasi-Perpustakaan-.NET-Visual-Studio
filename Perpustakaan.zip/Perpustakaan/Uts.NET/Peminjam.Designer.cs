﻿namespace Perpustakaan
{
    partial class Form_peminjam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_keluar = new Button();
            button_mengembalikan_buku = new Button();
            button_meminjam_buku = new Button();
            button_melihat_buku = new Button();
            dataGridView_tampilkan_data_buku = new DataGridView();
            button_cari = new Button();
            textBox_cari = new TextBox();
            label_cari = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView_tampilkan_data_buku).BeginInit();
            SuspendLayout();
            // 
            // button_keluar
            // 
            button_keluar.Location = new Point(674, 105);
            button_keluar.Name = "button_keluar";
            button_keluar.Size = new Size(90, 29);
            button_keluar.TabIndex = 35;
            button_keluar.Text = "Keluar";
            button_keluar.UseVisualStyleBackColor = true;
            button_keluar.Click += button_keluar_Click;
            // 
            // button_mengembalikan_buku
            // 
            button_mengembalikan_buku.Location = new Point(449, 105);
            button_mengembalikan_buku.Name = "button_mengembalikan_buku";
            button_mengembalikan_buku.Size = new Size(174, 29);
            button_mengembalikan_buku.TabIndex = 31;
            button_mengembalikan_buku.Text = "Mengembalikan Buku";
            button_mengembalikan_buku.UseVisualStyleBackColor = true;
            button_mengembalikan_buku.Click += button_mengembalikan_buku_Click;
            // 
            // button_meminjam_buku
            // 
            button_meminjam_buku.Location = new Point(194, 105);
            button_meminjam_buku.Name = "button_meminjam_buku";
            button_meminjam_buku.Size = new Size(184, 29);
            button_meminjam_buku.TabIndex = 30;
            button_meminjam_buku.Text = "Meminjam Buku";
            button_meminjam_buku.UseVisualStyleBackColor = true;
            button_meminjam_buku.Click += button_meminjam_buku_Click;
            // 
            // button_melihat_buku
            // 
            button_melihat_buku.Location = new Point(36, 105);
            button_melihat_buku.Name = "button_melihat_buku";
            button_melihat_buku.Size = new Size(116, 29);
            button_melihat_buku.TabIndex = 28;
            button_melihat_buku.Text = "Melihat Buku";
            button_melihat_buku.UseVisualStyleBackColor = true;
            button_melihat_buku.Click += button_melihat_buku_Click;
            // 
            // dataGridView_tampilkan_data_buku
            // 
            dataGridView_tampilkan_data_buku.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_tampilkan_data_buku.Location = new Point(36, 154);
            dataGridView_tampilkan_data_buku.Name = "dataGridView_tampilkan_data_buku";
            dataGridView_tampilkan_data_buku.RowHeadersWidth = 51;
            dataGridView_tampilkan_data_buku.RowTemplate.Height = 29;
            dataGridView_tampilkan_data_buku.Size = new Size(728, 241);
            dataGridView_tampilkan_data_buku.TabIndex = 27;
            // 
            // button_cari
            // 
            button_cari.Location = new Point(578, 49);
            button_cari.Name = "button_cari";
            button_cari.Size = new Size(186, 29);
            button_cari.TabIndex = 38;
            button_cari.Text = "Cari";
            button_cari.UseVisualStyleBackColor = true;
            button_cari.Click += button_cari_Click;
            // 
            // textBox_cari
            // 
            textBox_cari.Location = new Point(113, 49);
            textBox_cari.Name = "textBox_cari";
            textBox_cari.Size = new Size(449, 27);
            textBox_cari.TabIndex = 37;
            // 
            // label_cari
            // 
            label_cari.AutoSize = true;
            label_cari.Location = new Point(36, 56);
            label_cari.Name = "label_cari";
            label_cari.Size = new Size(71, 20);
            label_cari.TabIndex = 36;
            label_cari.Text = "Cari Buku";
            // 
            // Form_peminjam
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button_cari);
            Controls.Add(textBox_cari);
            Controls.Add(label_cari);
            Controls.Add(button_keluar);
            Controls.Add(button_mengembalikan_buku);
            Controls.Add(button_meminjam_buku);
            Controls.Add(button_melihat_buku);
            Controls.Add(dataGridView_tampilkan_data_buku);
            Name = "Form_peminjam";
            Text = "Peminjam";
            ((System.ComponentModel.ISupportInitialize)dataGridView_tampilkan_data_buku).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button_keluar;
        private Button button_mengembalikan_buku;
        private Button button_meminjam_buku;
        private Button button_melihat_buku;
        private DataGridView dataGridView_tampilkan_data_buku;
        private Button button_cari;
        private TextBox textBox_cari;
        private Label label_cari;
    }
}