﻿namespace Uts.NET
{
    partial class Form_login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label_nama = new Label();
            label_password = new Label();
            button_login = new Button();
            textBox_nama = new TextBox();
            textBox_password = new TextBox();
            button_admin = new Button();
            SuspendLayout();
            // 
            // label_nama
            // 
            label_nama.AutoSize = true;
            label_nama.Location = new Point(197, 171);
            label_nama.Name = "label_nama";
            label_nama.Size = new Size(49, 20);
            label_nama.TabIndex = 0;
            label_nama.Text = "Nama";
            // 
            // label_password
            // 
            label_password.AutoSize = true;
            label_password.Location = new Point(197, 216);
            label_password.Name = "label_password";
            label_password.Size = new Size(70, 20);
            label_password.TabIndex = 1;
            label_password.Text = "Password";
            // 
            // button_login
            // 
            button_login.Location = new Point(197, 283);
            button_login.Name = "button_login";
            button_login.Size = new Size(143, 29);
            button_login.TabIndex = 2;
            button_login.Text = "LOGIN";
            button_login.UseVisualStyleBackColor = true;
            button_login.Click += button_login_Click;
            // 
            // textBox_nama
            // 
            textBox_nama.Location = new Point(278, 164);
            textBox_nama.Name = "textBox_nama";
            textBox_nama.Size = new Size(331, 27);
            textBox_nama.TabIndex = 3;
            // 
            // textBox_password
            // 
            textBox_password.Location = new Point(278, 213);
            textBox_password.Name = "textBox_password";
            textBox_password.Size = new Size(331, 27);
            textBox_password.TabIndex = 4;
            // 
            // button_admin
            // 
            button_admin.Location = new Point(466, 283);
            button_admin.Name = "button_admin";
            button_admin.Size = new Size(143, 29);
            button_admin.TabIndex = 5;
            button_admin.Text = "ADMIN";
            button_admin.UseVisualStyleBackColor = true;
            button_admin.Click += button_admin_Click;
            // 
            // Form_login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 508);
            Controls.Add(button_admin);
            Controls.Add(textBox_password);
            Controls.Add(textBox_nama);
            Controls.Add(button_login);
            Controls.Add(label_password);
            Controls.Add(label_nama);
            Name = "Form_login";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label_nama;
        private Label label_password;
        private Button button_login;
        private TextBox textBox_nama;
        private TextBox textBox_password;
        private Button button_admin;
    }
}